function indicador(indicador, uid, value) {
	bridge.indicadores.indicador(indicador).add(uid, value);
}