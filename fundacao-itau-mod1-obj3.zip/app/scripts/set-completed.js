events.on("ready",function(){scorm.setCompleted()});
//# sourceMappingURL=set-completed.js.map
